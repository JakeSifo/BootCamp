var sum = require('./sum');
var bluebird = require('bluebird');
var sum = bluebird.promisifyAll(sum);

console.log('Before sumAsync() call')
var promise = sum.sumAsync(5,6);
console.log('After sumAsync() call');

promise.then(
    (data) => {
       console.log("Sum is: \n" + data);
    }) 
   .catch((err) => {
       console.log(err);
   });

console.log('After promise.then()');   