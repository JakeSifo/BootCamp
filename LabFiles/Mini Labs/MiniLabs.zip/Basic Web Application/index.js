var http = require('http');
var url = require('url');
const querystring = require('querystring');

var products = [
    {
      productId:1,
      title: "iPhone",
      quantity:400
    },
    {
      productId:2,
      title: "Android",
      quantity:500
    }
  ];

var server = http.createServer(function(req, res) {
    res.setHeader("Content-type", "application/json");

    const queryObject = url.parse(req.url,true).query;
    switch(req.method) {
      // GET method
      case "GET":
        // GET method and URL is /products
        if(req.url.startsWith("/products")) {
          // GET method and URL is /products with no query string
          if(queryObject.productId === undefined)
            res.write(JSON.stringify(products));
          else {
            // GET method and URL is /products with query string.
            var product = products.find( item => {
              console.log(item);
              return item.productId == queryObject.productId;
            });
            console.log(product);
            console.log("Done");
            res.write(JSON.stringify(product));

          }
        }
        res.end();
        break;
      // POST method
      case "POST":
        if(req.url === "/products") {
        var body = "";

        req.on("data", function(chunk) {
            body += chunk;
        });
      
        req.on("end", function() {
            var newProduct = JSON.parse(body);
            products.push(newProduct);
         });
         res.end();
         break;
      }
    }
});

server.listen(3000);