const defaultState = { 
    gstModel: {
      gstRate: '',
      price: ''
    },
    total: '',
    history: []
}

function appReducer(state=defaultState, action) {
 switch (action.type) {

  case 'UPDATE_FIELD':
    console.log('update field'); 
    let field = {};
    console.log(action);
    field[action.field_name] = action.field_value;
    let gstModel = Object.assign({}, state.gstModel, field);
    const obj = Object.assign({}, state, {gstModel: gstModel})
    console.log(obj);

    return obj;

   case 'CALCULATE_TOTAL': {
    console.log('calculate total'); 
    console.log(state);
    let result = (Number(state.gstModel.gstRate / 100) * Number(state.gstModel.price)) + Number(state.gstModel.price);
    console.log(result);
    let message = `${state.gstModel.price} + ${state.gstModel.gstRate}% = ${result}`;
    let newHistory = [message, ...state.history];
    const obj = Object.assign({}, state, {total: result}, {history: newHistory});
    console.log(obj);
    return obj;
    
   }
  
   default: {
    return state
   }
 }
}

export default appReducer