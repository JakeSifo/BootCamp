export function setField(field_name, field_value) {
    return {
        type: "UPDATE_FIELD",
        field_name: field_name,
        field_value: field_value 
    };
}

export function setTotal(){
    return {
        type: "CALCULATE_TOTAL",
    };
}
