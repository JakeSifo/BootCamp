import React, { Component } from 'react';
import { connect } from 'react-redux';
import { setTotal, setField } from './actions';
import './App.css';


class App extends Component {

  render() {
        return (
        <div>    
            <Header/>        
            <Body  {...this.props} />
            <Footer/>
        </div> );
    }
}

class Header extends Component {

    constructor(props) {
        super(props);
        this.title = "GST Calculator";
    }
    
    render() {
        return <h3>{this.title}</h3>;
    }
}

class Body extends Component {
    
    render() {
        return ( <div>
                   <GSTComponent {...this.props} /> 
                </div> );
    }
}

class Footer extends Component {
    constructor(props) {
        super(props);

        this.footerText = "Copyright 2023";
    }
    
    render() {
        return (<div>
            <h4>{this.footerText}</h4>
            </div>);
    }
}

class GSTComponent extends Component {
   
    render() {
        return <div>
            <p>GST Rate: <input type="number" name="gstRate" id="gstRate" onChange={(evt) => this.props.handleChange(evt)} /></p>
            <p>Price excluding GST: <input type="number" name="price" id="price" onChange={(evt) => this.props.handleChange(evt)} /></p>
            <p><input type="button" value="Calculate" name="btnCalculate" onClick={(evt) => this.props.onGstCalculateClick(evt)} /></p>
            <p>Total Amount: {this.props.total} </p>
            <hr/>
            <h2>History</h2>
            <ul>
             { this.props.history.map((item, index) => {
                return (<li key={index}>{item}</li>)
            })}
            </ul>
            
        </div>
    }
}

const mapStateToProps = function(state){
  return {
    gstModel: state.gstModel,
    total: state.total,
    history: state.history
  }
}


const mapDispatchToProps = function(dispatch){
  return {
    handleChange: (evt) => {
        dispatch(setField(evt.currentTarget.name, evt.currentTarget.value));
    },
    onGstCalculateClick: (event) => {
        dispatch(setTotal());
    }
  }
}

const VisibleApp = connect(
	mapStateToProps,
  	mapDispatchToProps
	)(App)


export default VisibleApp;
