var events = require('events');
var util = require('util');

var SportsCar = function SportsCar() {
    this.speed = 0;
    
    this.setMaxListeners(1);
    this.accelerate = function(increment) {
        var newSpeed = this.speed + increment;
        if(newSpeed > 100) {
            this.emit("overspeed", this.speed, newSpeed);
        } else {
            this.speed += increment;
        }
     }
}

util.inherits(SportsCar, events.EventEmitter);
module.exports.SportsCar = SportsCar;