var sports_car = require('./sports_car.js');
var car = new sports_car.SportsCar();
car.speed = 90;

car.on("overspeed", function(currentSpeed, speedWillBe) {
  console.log(`Cop #1 detected overspeeding!. Current speed is: ${currentSpeed}, New speed will be: ${speedWillBe}`);
 });
 
car.on("overspeed", function(currentSpeed, speedWillBe) {
  console.log(`Cop #2 detected overspeeding!. Current speed is: ${currentSpeed}, New speed will be: ${speedWillBe}`);
 });

setInterval(function() {
	car.accelerate(1);
	console.log(`The current speed is: ${car.speed}`);
 }, 1000);


  
  