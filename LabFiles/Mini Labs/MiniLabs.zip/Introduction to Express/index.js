var express = require('express');
var bodyParser = require('body-parser');
var dao = require("./data_access");

var app = express();

app.use(bodyParser.json()); //Parse JSON body
app.use(bodyParser.urlencoded({
    extended: true
}));

app.get("/products", function(req, res) {
    res.send(dao.getProducts());
});

app.get("/products/:product_id", function(req, res) {
  var Product = dao.findProduct(req.params.product_id);

  if (Product === undefined) {
    res.statusCode = 404;
    res.end();
  } else {
    res.send(Product);
  }
});

app.post("/products", function(req, res) {
  console.log(req.body);
  dao.updateProduct(req.body);
  res.end();
});

app.delete("/products/:product_id", function(req, res) {
  var Product = dao.findProduct(req.params.product_id);

  if (Product === undefined) {
    res.statusCode = 404;
    res.end();
  } else {
    dao.deleteProduct(req.params.product_id);
    res.end();
  }
});


app.listen(3000);