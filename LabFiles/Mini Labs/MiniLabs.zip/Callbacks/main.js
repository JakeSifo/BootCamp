var library = require('./gst');
let amount = 100;
let gstRate = 13;

library.calculateGst(amount, gstRate, (err, data) => {
	if(err != "") {
 		console.log(err);
 	} else {
 		console.log("The result is: " + data);
	}
});

console.log("This line will get called BEFORE sum is called!"); 