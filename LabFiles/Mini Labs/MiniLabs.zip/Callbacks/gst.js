var util = require('./util');

function calculateGst(amount, percent, callback) {
  if(amount < 0 || percent < 0) {
    callback("Amount and percent cannot be less than 0", 0);
  }
  else {
  //setImmediate(function() {
 		console.log("Calculating...");
 		util.pause(3000);

    callback("", amount * (percent / 100));
  //});
  }
}

module.exports.calculateGst = calculateGst;

