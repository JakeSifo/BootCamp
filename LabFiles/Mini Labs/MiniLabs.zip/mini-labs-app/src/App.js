import { useState } from 'react';
import './App.css';
import MiniLabRenderer from './MiniLabRenderer';
import MiniLabSelector from './MiniLabSelector';

function App() {
  let selectedMiniLab = sessionStorage.getItem("selectedMiniLabNumber");
  if (selectedMiniLab == null){ 
    let one = "1";
    sessionStorage.setItem("selectedMiniLabNumber",one);
    selectedMiniLab = one;
  }
  const [chosenMiniLab, setChosenMiniLab] = useState( +selectedMiniLab);
  let setSelectedMiniLab = function(selection){
    sessionStorage.setItem("selectedMiniLabNumber",selection);
    setChosenMiniLab(selection);
  }
  return (
    <div>
      Choose Lab: &nbsp;
      <MiniLabSelector selected={chosenMiniLab} setLab={setSelectedMiniLab} />
      <MiniLabRenderer chosenLabNumber={chosenMiniLab} />
    </div>
  )

}

export default App;
