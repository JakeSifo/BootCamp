import React from 'react';
import { useParams } from 'react-router-dom';

const state = {
  countries: [
    { 'name': 'Canada', 'capital': 'Ottawa', image: '/images/Canada.png' },
    { 'name': 'USA', 'capital': 'Washington, D.C.', image: '/images/US.png' }
  ]
};

const CountryDetails = () => {
  const params = useParams();
  const selectedCountry = state.countries[+params.index];

  return (
    <div className='page' >
      <h4>Details Page</h4>
      <div className='pageContent' >
        <table>
          <tbody>
            <tr>
              <td><b>Name:</b></td>
              <td>{selectedCountry.name}</td>
            </tr>
            <tr>
              <td><b>Capital:</b></td>
              <td>{selectedCountry.capital}</td>
            </tr>
            <tr>
              <td><b>Image:</b></td>
              <td><img src={selectedCountry.image}
                width='100px'
                alt='na' /></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default CountryDetails;