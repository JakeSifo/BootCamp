import React from 'react';
let title = "MiniLab04 - Fragments"

function ListItems(props){
    return (<React.Fragment>
        <li>Item One</li>
        <li>Item Two</li>
        <li>Item Three</li>
    </React.Fragment> );
 }

function Body(props){
    return <div>
        <h4>List:</h4>
        <ol>
            <ListItems />
        </ol>
    </div>;
}


function Header(){
    return <h3 className={'divstyle'} >{title}</h3>;
}

function Footer(props){
    return (<div><h4 className={'divstyle'} >Copyright 2022</h4></div>);
}

function MiniLab(){
    return (
    <div className={'boxed'}>    
        <Header />  
        <Body  />
        <Footer />
    </div> );
}

export default MiniLab