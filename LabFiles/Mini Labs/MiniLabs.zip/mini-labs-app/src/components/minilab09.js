import React, { useState } from 'react';

let _scope = {
    title:  "MiniLab09 - Unit Testing",
    taxInfo: { price: 100, taxRate: 15 },
    result: 0,
    list: ['Item One', 'Item Two', 'Item three']
}

 function TaxCalc(props){
    return <div>
        <p>Tax Rate: <input type="number" name="taxRate" id="taxRate" value={props.scope.taxInfo.taxRate} onChange={(evt) => props.handleChange(evt)} /></p>
        <p>Price excluding GST: <input type="number" name="price" id="price" value={props.scope.taxInfo.price} onChange={(evt) => props.handleChange(evt)} /></p>
        <p><input type="button" value="Calculate" name="btnCalculate" onClick={(evt) => props.getTotal(evt)} /></p>
        <p>Total Amount: <span data-testid="calc-result">{props.scope.result}</span> </p>
    </div>
 }

function Body(props){ 
    return <div>
        <TaxCalc {...props} />
    </div>;
}


function Header(props){
    return <h3 className={'divstyle'} >{props.title}</h3>;
}

function Footer(props){
    return (<div><h4 className={'divstyle'} >Copyright 2022</h4></div>);
}

function MiniLab(){
    const[scope, setScope]= useState( _scope );
    let handleChange = function (event) {
        scope.taxInfo[event.currentTarget.name] = event.currentTarget.value;
        setScope({...scope, taxInfo: scope.taxInfo });
    }
    let getTotal = function(){
        let rate = +scope.taxInfo.taxRate;
        let price = +scope.taxInfo.price;
        scope.result = (rate * price)/100 + price
        setScope({...scope, result: scope.result});
    }
    return (
    <div className={'boxed'}>    
        <Header title={scope.title}/>  
        <Body scope={scope} handleChange={handleChange} getTotal={getTotal} />
        <Footer />
    </div> );
}

export default MiniLab