import React from 'react';

class Body extends React.Component {
    // eslint-disable-next-line
    constructor(props) {
        super(props);
    }

    render() {
        return (<div>
            <h4>Counter:</h4>
            &nbsp;({this.props.scope.counter})&nbsp;
            <button onClick={()=>this.props.handleOnClick()} >Increment</button>
            <h4>List:</h4>
            <ul>
                {this.props.scope.list.map(function (item, index) {
                    return <li key={index}>{index}-{item}</li>
                })
                }
            </ul>
        </div>);
    }
}

function Header(props) {
    return <h3 className={'divstyle'} >{props.title}</h3>;
}

function Footer(props) {
    return (<div><h4 className={'divstyle'} >Copyright 2022</h4></div>);
}

class MiniLab extends React.Component {
    scope = {
        counter: 0,
        title: "MiniLab06 - Class Based Components",
        list: ['Monday', 'Tuesday', 'Wednesday']
    }

    // eslint-disable-next-line
    constructor(props) {
        super(props);
        this.handleOnClick = this.handleOnClick.bind(this);
    }

    handleOnClick(){
        let newScope = {...this.scope, counter: this.scope.counter + 1};
        this.scope = newScope;
        this.setState(newScope);
    }

    render() {
        return (
            <div className={'boxed'}>
                <Header title={this.scope.title} />
                <Body scope={this.scope} handleOnClick={this.handleOnClick} />
                <Footer />
            </div>);
    }
}

export default MiniLab