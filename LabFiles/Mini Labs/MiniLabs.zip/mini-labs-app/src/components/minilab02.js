import {useState} from 'react';

const title = "DOM Updates"
const divStyle = {
    backgroundColor: 'lightgrey',
    margin: '0px',
    padding: '5px', 
    textAlign: 'center',
};

var footerText = "Copyright 2022"

function MiniLab(){
    const[count, setCount]= useState(0);
    let handleClick = ()=>{
        let newCount = count + 1;
        setCount(newCount);
    }
    return (
    <div className={'boxed'}>    
        <Header /> 
        <button onClick={()=>handleClick()} >Click Here</button>      
        <Body  count={count} />
        <Footer text={footerText} />
    </div> );
}

function Header(){
    return <h3 style={divStyle} >{title}</h3>;
}


function Body(props){
    return <div>
    {props.count} 
  </div>;
}

function Footer(props){
    return (<div>
        <h4 style={divStyle} >{props.text}</h4>
        </div>);
}

export default MiniLab