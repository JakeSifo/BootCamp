import React, {useState}from 'react';
import { BrowserRouter, Routes, Route, Link} from 'react-router-dom'
import Countries from './countries'
import CountryDetails from './countryDetails'

let _scope = {
    title:  "MiniLab07 - Router",
    taxInfo: { price: 100, taxRate: 15 },
    result: 0,
    list: ['Item One', 'Item Two', 'Item three']
}

  function RouteExample() {  

    return ( <BrowserRouter>
      <div>
        <nav>
          <Link to='/countries'>Countries</Link>&nbsp;
          <Link to='/details/0'>Details</Link><br/>
        </nav>
        <Routes>
          <Route path="" element={<Countries />} />
          <Route exact path="/countries" element={<Countries />} />
          <Route path="/details/:index" element={<CountryDetails />} />
        </Routes>
      </div>
    </BrowserRouter>);
  }

function Body(props){ 
    return <div>
        <RouteExample {...props} />
    </div>;
}


function Header(props){
    return <h3 className={'divstyle'} >{props.title}</h3>;
}

function Footer(props){
    return (<div><h4 className={'divstyle'} >Copyright 2022</h4></div>);
}

function MiniLab(){
    const[scope, setScope]= useState(_scope);
    let handleChange = function (event) {
        scope.taxInfo[event.currentTarget.name] = event.currentTarget.value;
        setScope({...scope, taxInfo: scope.taxInfo });
    }
    let getTotal = function(){
        console.log('in gettotal');
        let rate = +scope.taxInfo.taxRate;
        let price = +scope.taxInfo.price;
        scope.result = (rate * price)/100 + price
        setScope({...scope, result: scope.result});
    }
    return (
    <div className={'boxed'}>    
        <Header title={scope.title}/>  
        <Body scope={scope} handleChange={handleChange} getTotal={getTotal} />
        <Footer />
    </div> );
}

export default MiniLab