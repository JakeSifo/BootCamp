import {useState, useEffect} from 'react';

export function useProducts() {
    let state = { _products: [] }

    const [products, setProducts] = useState(state._products);

    useEffect(() => {
        fetch('/products.json')
            .then(res => res.json())
            .then((data) => {
                setProducts(data);
            })
            .catch(console.log)
    }, []);

    const repository = {
        list() { return products; },
        byIndex(idx) { return products[idx]; }
    }

    return repository;
}

