import React, {useState}from 'react';
import { useProducts } from './CustomHook';
import './minilab08.css';

let _scope = {
    title:  "MiniLab08 - Custom Hook",
    taxInfo: { price: 100, taxRate: 15 },
    result: 0,
    list: ['Item One', 'Item Two', 'Item three']
}

function ProductList() {
    const products = useProducts();
    const [selectedIndex, setSelectedIndex] = useState(-1);
  
    function handleSelectClick(evt, index) {
      setSelectedIndex(index);
    }
  
    return (
      <div>
        <table>
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {
              products.list().map((product, index) => {
                return (
                  <tr key={product.productId}>
                    <td>{product.productId}</td>
                    <td>{product.productTitle}</td>
                    <td>{product.price} &nbsp;
                      <input type='button' value='Select' onClick={(evt) => handleSelectClick(evt, index)} /></td>
                  </tr>
                )
              })
            }
          </tbody>
        </table>
  
        {(selectedIndex >= 0) ?
          (<div>
            Product Id: {products.byIndex(selectedIndex).productId}<br/>
            Product Title: {products.byIndex(selectedIndex).productTitle}<br/>
            Quantity: {products.byIndex(selectedIndex).price}<br/>
          </div>)
          : ''}
  
      </div>
    );
  }

function Body(props){ 
    return <div>
    <ProductList />
    </div>;
}

function Header(props){
    return <h3 className={'divstyle'} >{props.title}</h3>;
}

function Footer(props){
    return (<div><h4 className={'divstyle'} >Copyright 2022</h4></div>);
}

function MiniLab(){
    const[scope]= useState(_scope);
    return (
    <div className={'boxed'}>    
        <Header title={scope.title}/>  
        <Body scope={scope} />
        <Footer />
    </div> );
}

export default MiniLab