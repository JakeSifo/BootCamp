let title = "MiniLab - Transpile"
let bodyContent = "The name is Bob!"
let footerText = "Copyright 2022"

function Header(){
    return <h3 className={'divstyle'} >{title}</h3>;
}

function Body(props){
    return <div>{props.bodyContent}</div>;
}

function Footer(props){
    return (<div><h4 className={'divstyle'} >{props.text}</h4></div>);
}

function MiniLab(){
    return (
    <div className={'boxed'}>    
        <Header />  
        <Body  bodyContent={bodyContent} />
        <Footer text={footerText} />
    </div> );
}

export default MiniLab