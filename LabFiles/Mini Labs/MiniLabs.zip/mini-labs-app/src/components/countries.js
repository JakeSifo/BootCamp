import React from 'react'
import { Link } from 'react-router-dom'

const state = {
  countries: [
    { 'name': 'Canada' },
    { 'name': 'USA' }
  ]
};

const listItems = state.countries.map((item, index) => {
  return <li key={index} ><Link to={'/details/' + index } >{item.name}</Link></li>
});

const Countries = (list) => {
  return (
    <div className='page' >
      <h4>Countries List</h4>
      <div className='pageContent' >
        <ul>
          {listItems}
        </ul>
      </div>
    </div>
  )
}

export default Countries;