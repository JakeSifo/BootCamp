import React from 'react';
import {render, fireEvent, waitFor, screen, } from '@testing-library/react'
import '@testing-library/jest-dom'
import TaxCalculator from './minilab09';

describe("minilab09 test suite", ()=>{
    it('TaxCalculator instantiates without issue', async () => {
        // instantiate the component
        render(<TaxCalculator />)

     });

     it('TaxCalculator calculates from default values', async () => {
        // instantiate the component
        render(<TaxCalculator />)

        // click the [Calculate] button virtually
        fireEvent.click(screen.getByText('Calculate'))

        // wait for the output to update
        await waitFor(
            ()=> screen.getByTestId("calc-result")
        )
        // check value against expected outcome
        expect(screen.getByTestId("calc-result").innerHTML).toBe("115");
     });

});

