let MiniLabSelector = function (params) {
    let onSelect = function () {
      let value = +document.getElementById("select").value;
      console.log('you chose: ' + value)
      params.setLab(value);
    }
    let result =
      <select name="cars" id="select" value={params.selected} onChange={() => { onSelect(); }} >
        <option value="1">MiniLab 01</option>
        <option value="2">MiniLab 02</option>
        <option value="3">MiniLab 03</option>
        <option value="4">MiniLab 04</option>
        <option value="5">MiniLab 05</option>
        <option value="6">MiniLab 06</option>   
        <option value="7">MiniLab 07</option> 
        <option value="8">MiniLab 08</option>     
        <option value="9">MiniLab 09</option>
      </select>
  
    return result
  }

  export default MiniLabSelector