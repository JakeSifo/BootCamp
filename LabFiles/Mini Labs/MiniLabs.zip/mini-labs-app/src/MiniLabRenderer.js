import MiniLab01 from './components/minilab01'
import MiniLab02 from './components/minilab02'
import MiniLab03 from './components/minilab03'
import MiniLab04 from './components/minilab04'
import MiniLab05 from './components/minilab05'
import MiniLab06 from './components/minilab06'
import MiniLab07 from './components/minilab07'
import MiniLab08 from './components/minilab08'
import MiniLab09 from './components/minilab09'

let MiniLabDefault = function () { return <h1>MiniLabDefault</h1> }

let MiniLabRenderer = function (params) {
  let miniLabNumber = +params.chosenLabNumber
  switch (miniLabNumber) {
    case 1:
      return <MiniLab01 />
    case 2:
      return <MiniLab02 />
    case 3:
      return <MiniLab03 />
    case 4:
      return <MiniLab04 />
    case 5:
      return <MiniLab05 />
    case 6:
      return <MiniLab06 />
    case 7:
      return <MiniLab07 />
    case 8:
      return <MiniLab08 />
    case 9:
      return <MiniLab09 />
    default:
      return <MiniLabDefault />
  }
}

export default MiniLabRenderer

