var products = [{
  "productId": 1,
  "title":"iPhone",
  "quantity":300
},
{
  "productId": 2,
  "title":"Android",
  "quantity":400
}]; 

module.exports.getProducts = function() {
 return products;
};

module.exports.findProduct = function(product_id) {
  return products.find(item => {
   return item.productId == product_id
})
};

module.exports.updateProduct = function(product) {
  products.push( product );
};

module.exports.deleteProduct = function(product_id) {
  var index = -1;
  products.find((item, i) => {
    if(item.productId == product_id) {
      index = i;
      return;
    }
  });
  products.splice(index, 1);

};
