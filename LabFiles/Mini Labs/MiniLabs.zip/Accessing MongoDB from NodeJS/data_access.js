var mongodb = require("mongodb");
var dbPool; //Connection pool
var url = "mongodb://localhost:9999/sales_db";

mongodb.MongoClient.connect(url, function(err, db) {
    if (err === null) {
        dbPool = db; //Open the pool
    }
});


// GET ALL PRODUCTS
module.exports.findProducts = function(callback) {
  var col = dbPool.collection("Products");
  
  col.find().toArray((err, products) => {
      if (err == null && products.length > 0) {
        callback(null, products);
      } else {
        callback("Product not found!");
      }
  });
};

// INSERT PRODUCT
module.exports.insertProduct = function(product, callback) {
   var col = dbPool.collection("Products");

   col.insert(product, callback);
 };
