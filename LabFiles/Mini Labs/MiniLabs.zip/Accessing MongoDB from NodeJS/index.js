var express = require('express');
var bodyParser = require('body-parser');
var dao = require("./data_access");

var app = express();

app.use(bodyParser.json()); //Parse JSON body

app.get("/products", (req, res) => {
  dao.findProducts((err, products) => {
    if (products !== undefined) {
      res.send(products);
    } else {
      res.statusCode = 404;
      res.end();
    }
  });
});

app.post("/products",(req, res) => {
  if (req.body === undefined) {
    res.statusCode = 500;
    res.end();

    return;
  }

  dao.insertProduct(req.body, (err) => {
    if (err !== null) {
      res.statusCode = 500;
    }
    res.end();
  });
});

app.listen(3000);