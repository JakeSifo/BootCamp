import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>First App</h1>
      <p>Some text...</p>
    </div>
  );
}

export default App;
