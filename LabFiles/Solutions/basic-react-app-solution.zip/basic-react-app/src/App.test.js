import { render, screen } from '@testing-library/react';
import App from './App';

test('app renders', () => {
  let container = render(<App />);
  expect(container).toBeTruthy();
});

test('renders header section', () => {
  render(<App />);
  const headerTextElement = screen.getByText(/Basic React Application/i);
  console.log("HEADER: " + headerTextElement.innerHTML );
  expect(headerTextElement).toBeInTheDocument();
});

test('renders footer section', () => {
  const { container } = render(<App />);
  const footerElement = container.querySelector('footer');
  console.log("FOOTER: " + footerElement.innerHTML );
  expect(footerElement).toBeTruthy();
});

test('renders article section', () => {
  const { container } = render(<App />);
  const articleElement = container.querySelector('article');
  console.log("ARTICLE: " + articleElement.innerHTML );
  expect(articleElement).toBeTruthy();
});

