import logo from './logo.svg';
import './App.css';

function App() {
  let articleContent = "One of the common and basic questions among students or someone who wants to learn code is “How can I learn to code fast and make a career as a programmer?”. Whether you are a student, fresher or experienced person trying to switch your job in programming you will definitely try to find tips and tricks to learn programming quickly and effectively. The job of programmers is one of the high-paid jobs in the market and one of the coolest jobs people find to do. Learning to code and mastering it can take years for a beginner. Most people give up before they truly get started. In the beginning, we get very excited about the concept of learning to code, but later in most of cases students or beginners give up quickly because they find it difficult to continue, they get stuck and they face difficulty in finding the solution for a code. Learning to program isn’t an overnight journey but it’s also not as difficult as people think about it, all it just requires is dedication, passion, interest, and definitely patience. There are so many online and offline resources available to learn to code easily, quickly, and effectively. We will discuss some tips to learn programming effectively and faster.";
  return (
    <div className="App">
      <header className="App-header">
        <h1>Basic React Application</h1>
      </header>
      <article>
        <h2>Programming Tips & Tricks</h2>
        <p>{articleContent}</p>
      </article>
      <footer>
        <span>© Best Design Inc.</span>
        <br/>
        <a href="www.bestdesign.com" >www.bestdesign.com</a>
      </footer>
    </div>
  );
}


export default App;
